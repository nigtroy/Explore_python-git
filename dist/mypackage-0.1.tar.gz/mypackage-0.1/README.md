# mypackage
This library was created as an example of hiww to publish pypur own Python package
